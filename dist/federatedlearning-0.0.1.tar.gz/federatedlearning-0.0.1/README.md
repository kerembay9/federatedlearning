federated learning library
